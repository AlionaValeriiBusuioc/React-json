import React, { Component } from 'react';
import PostData from '../data/posts.json';

class PostList extends Component {
render(){
  return (
    <div>
     {/* <h1>Hello There</h1> */}
     {/* fiecare portiune de obiect din json e postDetail */}
     {PostData.map((postDetail, index)=>{    
     return <div>
    <p>{postDetail.id}</p>
    <h1>{postDetail.title}</h1>
     <p>{postDetail.content}</p>
     <p>{postDetail.slug}</p>
      </div>
     })} 
    </div>
  )
}
}

export default PostList;
