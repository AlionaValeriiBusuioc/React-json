import React from 'react';
import PostList from './posts/PostList';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
  <PostList/>
    </div>
  );
}

export default App;
